package org.example.minimarketzea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinimarketZeaApplicationTests {

    @Test
    void contextLoads() {
    }

}
