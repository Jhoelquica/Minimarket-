package dto;

public class PagoDTO {
    private Long compraId;
    private String tipoPago;      // "YAPE" o "TRANSFERENCIA"
    private String nroOperacion;  // número de operación
    private String datosCliente;  // datos adicionales (opcional)

    public PagoDTO() {}

    public Long getCompraId() { return compraId; }
    public void setCompraId(Long compraId) { this.compraId = compraId; }

    public String getTipoPago() { return tipoPago; }
    public void setTipoPago(String tipoPago) { this.tipoPago = tipoPago; }

    public String getNroOperacion() { return nroOperacion; }
    public void setNroOperacion(String nroOperacion) { this.nroOperacion = nroOperacion; }

    public String getDatosCliente() { return datosCliente; }
    public void setDatosCliente(String datosCliente) { this.datosCliente = datosCliente; }
}
