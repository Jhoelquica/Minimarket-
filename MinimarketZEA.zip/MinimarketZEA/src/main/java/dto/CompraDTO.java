package dto;

public class CompraDTO {
    private Long clienteId;
    private Double total;
    private String metodoPago; // "YAPE" o "TRANSFERENCIA"

    public CompraDTO() {}

    public Long getClienteId() { return clienteId; }
    public void setClienteId(Long clienteId) { this.clienteId = clienteId; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
}
