package dto;

public class BoletaPdfDTO {
    private Long id;
    private Long ventaId;
    private byte[] archivoPdf; // Contenido binario del PDF

    public BoletaPdfDTO() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getVentaId() { return ventaId; }
    public void setVentaId(Long ventaId) { this.ventaId = ventaId; }

    public byte[] getArchivoPdf() { return archivoPdf; }
    public void setArchivoPdf(byte[] archivoPdf) { this.archivoPdf = archivoPdf; }
}
