package controlador;

import modelo.Producto;
import servicio.ServicioProducto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ControladorProducto {

    private final ServicioProducto servicioProducto;

    public ControladorProducto(ServicioProducto servicioProducto) {
        this.servicioProducto = servicioProducto;
    }

    // Endpoint para obtener todos los productos
    @GetMapping("/api/productos")
    public ResponseEntity<List<Producto>> obtenerTodosLosProductos() {
        List<Producto> productos = servicioProducto.listarTodos();

        // Si no hay productos, devolvemos 204 No Content
        if (productos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // Devolver productos con el estado 200 OK
        return ResponseEntity.ok(productos);
    }

    // Endpoint para obtener un producto por ID
    @GetMapping("/api/productos/{id}")
    public ResponseEntity<Producto> obtenerProductoPorId(@RequestParam Long id) {
        Producto producto = servicioProducto.obtenerPorId(id);

        // Si no existe el producto, devolvemos 404 Not Found
        if (producto == null) {
            return ResponseEntity.notFound().build();
        }

        // Devolver producto con el estado 200 OK
        return ResponseEntity.ok(producto);
    }
}
