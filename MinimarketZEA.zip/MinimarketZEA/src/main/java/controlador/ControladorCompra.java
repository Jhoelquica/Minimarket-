package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/compras")
public class ControladorCompra {

    @PostMapping("/finalizar")
    public ResponseEntity<?> finalizarCompra(@RequestBody /*CompraDTO*/ Object compraDto) {
        // Procesar compra y seleccionar método de pago (Yape o transferencia)
        return ResponseEntity.ok("Compra registrada. Proceda con el pago.");
    }
}