package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pagos")
public class ControladorPago {

    @PostMapping("/confirmar")
    public ResponseEntity<?> confirmarPago(@RequestBody /*PagoDTO*/ Object pagoDto) {
        // Validar número de operación y datos, confirmar pago
        return ResponseEntity.ok("Pago confirmado");
    }
}
