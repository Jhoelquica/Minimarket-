package controlador;

import modelo.Compra;
import servicio.ServicioReporte;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ControladorReporte {

    private final ServicioReporte servicioReporte;

    public ControladorReporte(ServicioReporte servicioReporte) {
        this.servicioReporte = servicioReporte;
    }

    // Endpoint para obtener reporte de compras por cliente
    @GetMapping("/api/reportes/compras")
    public ResponseEntity<List<Compra>> generarReporteCompras(@RequestParam Long clienteId) {
        // Obtener las compras desde el servicio
        List<Compra> compras = servicioReporte.generarReporteComprasPorCliente(clienteId);

        // Si no hay compras, devolvemos un código 204 No Content
        if (compras.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // Si hay compras, devolvemos las compras en el cuerpo con un código 200 OK
        return ResponseEntity.ok(compras);
    }

    // Endpoint para obtener reporte de compras por estado
    @GetMapping("/api/reportes/compras/estado")
    public ResponseEntity<List<Compra>> generarReporteComprasPorEstado(@RequestParam String estado) {
        // Obtener compras por estado desde el servicio
        List<Compra> compras = servicioReporte.generarReporteComprasPorEstado(estado);

        // Si no hay compras, devolvemos un código 204 No Content
        if (compras.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // Si hay compras, devolvemos las compras en el cuerpo con un código 200 OK
        return ResponseEntity.ok(compras);
    }
}
