package controlador;

import modelo.ItemCarrito;
import servicio.ServicioCarrito;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ControladorCarrito {

    private final ServicioCarrito servicioCarrito;

    public ControladorCarrito(ServicioCarrito servicioCarrito) {
        this.servicioCarrito = servicioCarrito;
    }

    // Ejemplo de endpoint para obtener los items del carrito
    @GetMapping("/api/carrito")
    public ResponseEntity<List<ItemCarrito>> obtenerItemsCarrito(@RequestParam Long clienteId) {
        // Llamada al servicio para obtener los items del carrito
        List<ItemCarrito> itemsCarrito = servicioCarrito.obtenerCarritoPorCliente(clienteId);

        // Verifica si los items existen
        if (itemsCarrito.isEmpty()) {
            return ResponseEntity.noContent().build(); // Si no hay items, devuelve un 204 No Content
        }

        // Devolver la respuesta con el cuerpo (body) correcto y el código de estado 200 OK
        return ResponseEntity.ok(itemsCarrito); // Respuesta con items en el cuerpo
    }
}
