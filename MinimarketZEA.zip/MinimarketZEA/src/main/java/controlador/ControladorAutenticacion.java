package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class ControladorAutenticacion {

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody /*LoginDTO*/ Object loginDto) {
        // Lógica para autenticar y devolver JWT token
        return ResponseEntity.ok("Token JWT");
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registrarUsuario(@RequestBody /*RegistroDTO*/ Object registroDto) {
        // Lógica para registrar nuevo usuario
        return ResponseEntity.ok("Usuario registrado");
    }
}
