package controlador;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayInputStream;
import java.io.IOException;

@RestController
public class ControladorVenta {

    // Ejemplo: Método para devolver un archivo PDF
    @GetMapping("/api/venta/{id}/pdf")
    public ResponseEntity<byte[]> generarPDFVenta(Long id) throws IOException {
        // Aquí puedes generar tu archivo PDF y convertirlo a byte[]
        byte[] archivoPdf = generarPdf(); // método que genera el PDF en byte[] (usa iText o alguna librería similar)

        // Establecer encabezados HTTP
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=venta_" + id + ".pdf");

        // Devolver ResponseEntity con los datos binarios y el tipo de contenido adecuado
        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)  // Establecer tipo de contenido PDF
                .body(archivoPdf);  // El cuerpo es el byte[] generado
    }

    // Método ficticio para generar el PDF en byte[]
    private byte[] generarPdf() {
        // Lógica para generar un PDF y devolverlo como byte[]
        // Aquí puedes usar iText u otra librería para crear el PDF.
        return new byte[0];  // Devolver byte[] vacío por ahora
    }
}
