package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/proveedores")
public class ControladorProveedor {

    @GetMapping
    public ResponseEntity<List</*ProveedorDTO*/ Object>> listarProveedores() {
        // Retornar lista proveedores
        return ResponseEntity.ok(List.of(/* proveedores */));
    }

    @PostMapping
    public ResponseEntity<?> registrarProveedor(@RequestBody /*ProveedorDTO*/ Object proveedorDto) {
        // Registrar proveedor
        return ResponseEntity.ok("Proveedor registrado");
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarProveedor(@PathVariable Long id, @RequestBody /*ProveedorDTO*/ Object proveedorDto) {
        // Actualizar proveedor
        return ResponseEntity.ok("Proveedor actualizado");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarProveedor(@PathVariable Long id) {
        // Eliminar proveedor
        return ResponseEntity.ok("Proveedor eliminado");
    }
}