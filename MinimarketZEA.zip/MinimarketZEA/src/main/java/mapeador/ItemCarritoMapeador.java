package mapeador;

import dto.ItemCarritoDTO;
import modelo.ItemCarrito;
import org.springframework.stereotype.Component;

@Component
public class ItemCarritoMapeador {

    public ItemCarritoDTO toDTO(ItemCarrito item) {
        if (item == null) return null;
        ItemCarritoDTO dto = new ItemCarritoDTO();
        dto.setProductoId(item.getProducto() != null ? item.getProducto().getId() : null);
        dto.setNombreProducto(item.getProducto() != null ? item.getProducto().getNombre() : null);
        dto.setCantidad(item.getCantidad());
        dto.setPrecioUnitario(item.getProducto() != null ? item.getProducto().getPrecio() : null);
        return dto;
    }

    public ItemCarrito toEntidad(ItemCarritoDTO dto) {
        if (dto == null) return null;
        ItemCarrito item = new ItemCarrito();
        // Producto debe ser seteado en servicio al buscarlo por ID
        item.setCantidad(dto.getCantidad());
        return item;
    }
}
