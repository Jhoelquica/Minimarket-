package mapeador;

import dto.BoletaPdfDTO;
import modelo.BoletaPdf;
import org.springframework.stereotype.Component;

@Component
public class BoletaPdfMapeador {

    public BoletaPdfDTO toDTO(BoletaPdf boleta) {
        if (boleta == null) return null;
        BoletaPdfDTO dto = new BoletaPdfDTO();
        dto.setId(boleta.getId());
        dto.setVentaId(boleta.getVenta() != null ? boleta.getVenta().getId() : null);
        dto.setArchivoPdf(boleta.getArchivoPdf());
        return dto;
    }

    public BoletaPdf toEntidad(BoletaPdfDTO dto) {
        if (dto == null) return null;
        BoletaPdf boleta = new BoletaPdf();
        boleta.setId(dto.getId());
        boleta.setArchivoPdf(dto.getArchivoPdf());
        // Venta debe asignarse en servicio
        return boleta;
    }
}

