package mapeador;

import dto.VentaDTO;
import dto.DetalleVentaDTO;
import modelo.Venta;
import modelo.DetalleVenta;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class VentaMapeador {

    private final DetalleVentaMapeador detalleVentaMapeador;

    public VentaMapeador(DetalleVentaMapeador detalleVentaMapeador) {
        this.detalleVentaMapeador = detalleVentaMapeador;
    }

    public VentaDTO toDTO(Venta venta) {
        if (venta == null) return null;
        VentaDTO dto = new VentaDTO();
        dto.setId(venta.getId());
        dto.setCompraId(venta.getCompra() != null ? venta.getCompra().getId() : null);
        dto.setFechaVenta(venta.getFechaVenta());
        dto.setTotal(venta.getTotal());

        // Convertir detalles de venta
        List<DetalleVentaDTO> detallesDto = venta.getDetalles().stream()
                .map(detalleVentaMapeador::toDTO)
                .collect(Collectors.toList());
        dto.setDetalles(detallesDto);

        return dto;
    }

    public Venta toEntidad(VentaDTO dto) {
        if (dto == null) return null;
        Venta venta = new Venta();
        venta.setId(dto.getId());
        venta.setFechaVenta(dto.getFechaVenta());
        venta.setTotal(dto.getTotal());
        // Aquí puedes asignar compra y detalles si es necesario
        return venta;
    }
}
