package mapeador;

import dto.DetalleVentaDTO;
import modelo.DetalleVenta;
import org.springframework.stereotype.Component;

@Component
public class DetalleVentaMapeador {

    // Método para convertir DetalleVenta a DetalleVentaDTO
    public DetalleVentaDTO toDTO(DetalleVenta detalleVenta) {
        if (detalleVenta == null) return null;
        DetalleVentaDTO dto = new DetalleVentaDTO();
        dto.setProductoId(detalleVenta.getProducto().getId());
        dto.setNombreProducto(detalleVenta.getProducto().getNombre());
        dto.setCantidad(detalleVenta.getCantidad());
        dto.setPrecioUnitario(detalleVenta.getPrecioUnitario());
        return dto;
    }

    // Método para convertir DetalleVentaDTO a DetalleVenta
    public DetalleVenta toEntidad(DetalleVentaDTO dto) {
        if (dto == null) return null;
        DetalleVenta detalleVenta = new DetalleVenta();
        detalleVenta.setCantidad(dto.getCantidad());
        detalleVenta.setPrecioUnitario(dto.getPrecioUnitario());
        // Producto debe ser asignado desde otro servicio o repositorio
        return detalleVenta;
    }
}
