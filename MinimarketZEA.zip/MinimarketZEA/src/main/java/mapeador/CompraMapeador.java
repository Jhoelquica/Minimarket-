package mapeador;

import dto.CompraDTO;
import modelo.Compra;
import org.springframework.stereotype.Component;

@Component
public class CompraMapeador {

    public CompraDTO toDTO(Compra compra) {
        if (compra == null) return null;

        CompraDTO dto = new CompraDTO();
        dto.setClienteId(compra.getCliente() != null ? compra.getCliente().getId() : null);
        dto.setTotal(compra.getTotal());

        // Convertir el enum MetodoPago a String
        dto.setMetodoPago(compra.getMetodoPago() != null ? compra.getMetodoPago().name() : null);

        return dto;
    }

    public Compra toEntidad(CompraDTO dto) {
        if (dto == null) return null;

        Compra compra = new Compra();
        compra.setTotal(dto.getTotal());

        // Convertir el String a MetodoPago (si es necesario)
        if (dto.getMetodoPago() != null) {
            compra.setMetodoPago(Compra.MetodoPago.valueOf(dto.getMetodoPago()));
        }

        return compra;
    }
}
