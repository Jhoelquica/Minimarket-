package mapeador;

import dto.PagoDTO;
import modelo.Pago;
import org.springframework.stereotype.Component;

@Component
public class PagoMapeador {

    public PagoDTO toDTO(Pago pago) {
        if (pago == null) return null;

        PagoDTO dto = new PagoDTO();
        dto.setCompraId(pago.getCompra() != null ? pago.getCompra().getId() : null);

        // Convertir el enum TipoPago a String
        dto.setTipoPago(pago.getTipoPago() != null ? pago.getTipoPago().name() : null);

        dto.setNroOperacion(pago.getNroOperacion());
        dto.setDatosCliente(pago.getDatosCliente());
        return dto;
    }

    public Pago toEntidad(PagoDTO dto) {
        if (dto == null) return null;

        Pago pago = new Pago();
        // Convertir el String a TipoPago (si es necesario)
        if (dto.getTipoPago() != null) {
            pago.setTipoPago(Pago.TipoPago.valueOf(dto.getTipoPago()));
        }
        pago.setNroOperacion(dto.getNroOperacion());
        pago.setDatosCliente(dto.getDatosCliente());

        return pago;
    }
}

