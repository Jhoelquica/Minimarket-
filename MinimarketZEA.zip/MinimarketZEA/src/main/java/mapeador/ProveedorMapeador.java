package mapeador;

import dto.ProveedorDTO;
import modelo.Proveedor;
import org.springframework.stereotype.Component;

@Component
public class ProveedorMapeador {

    public ProveedorDTO toDTO(Proveedor proveedor) {
        if (proveedor == null) return null;
        ProveedorDTO dto = new ProveedorDTO();
        dto.setId(proveedor.getId());
        dto.setNombre(proveedor.getNombre());
        dto.setContacto(proveedor.getContacto());
        return dto;
    }

    public Proveedor toEntidad(ProveedorDTO dto) {
        if (dto == null) return null;
        Proveedor proveedor = new Proveedor();
        proveedor.setId(dto.getId());
        proveedor.setNombre(dto.getNombre());
        proveedor.setContacto(dto.getContacto());
        return proveedor;
    }
}
