package utilidades;

import java.text.SimpleDateFormat;
import java.util.Date;

public class UtilFechas {

    // Obtener la fecha actual en formato yyyy-MM-dd
    public static String obtenerFechaActual() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(new Date());
    }

    // Obtener la fecha actual en formato personalizado
    public static String obtenerFechaActualConFormato(String formato) {
        SimpleDateFormat sdf = new SimpleDateFormat(formato);
        return sdf.format(new Date());
    }

    // Convertir una cadena a tipo Date
    public static Date convertirStringADate(String fechaStr, String formato) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat(formato);
        return sdf.parse(fechaStr);
    }

    // Comparar dos fechas
    public static boolean compararFechas(Date fecha1, Date fecha2) {
        return fecha1.equals(fecha2);
    }

    public static void main(String[] args) {
        // Ejemplo de uso
        System.out.println("Fecha actual: " + obtenerFechaActual());
        System.out.println("Fecha personalizada: " + obtenerFechaActualConFormato("dd/MM/yyyy"));
        try {
            Date fecha1 = convertirStringADate("2025-05-20", "yyyy-MM-dd");
            Date fecha2 = convertirStringADate("2025-05-20", "yyyy-MM-dd");
            System.out.println("Fechas iguales: " + compararFechas(fecha1, fecha2));
        } catch (Exception e) {
            System.err.println("Error en la conversión de fechas: " + e.getMessage());
        }
    }
}
