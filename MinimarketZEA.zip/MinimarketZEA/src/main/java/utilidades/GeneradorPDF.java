package utilidades;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Text;

import java.io.File;
import java.io.IOException;

public class GeneradorPDF {

    // Método para generar un PDF básico
    public void generarPDF(String rutaArchivo, String contenido) throws IOException {
        // Crear el escritor de PDF
        PdfWriter writer = new PdfWriter(rutaArchivo);

        // Crear documento PDF
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        // Cargar la fuente (usamos la fuente estándar Helvetica)
        PdfFont font = PdfFontFactory.createFont(StandardFonts.HELVETICA);

        // Agregar contenido al documento usando la fuente
        Paragraph paragraph = new Paragraph();
        paragraph.add(new Text(contenido).setFont(font).setFontSize(12).setFontColor(ColorConstants.BLACK));

        document.add(paragraph);

        // Cerrar documento
        document.close();
    }

    // Método para generar un PDF con título y cuerpo
    public void generarPDFConTitulo(String rutaArchivo, String titulo, String contenido) throws IOException {
        // Crear el escritor de PDF
        PdfWriter writer = new PdfWriter(rutaArchivo);

        // Crear documento PDF
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        // Cargar la fuente (usamos la fuente estándar Helvetica)
        PdfFont font = PdfFontFactory.createFont(StandardFonts.HELVETICA);

        // Título
        Paragraph tituloParrafo = new Paragraph();
        tituloParrafo.add(new Text(titulo).setFont(font).setFontSize(18).setFontColor(ColorConstants.BLUE));
        document.add(tituloParrafo);

        // Espacio entre título y contenido
        document.add(new Paragraph("\n"));

        // Contenido
        Paragraph contenidoParrafo = new Paragraph();
        contenidoParrafo.add(new Text(contenido).setFont(font).setFontSize(12).setFontColor(ColorConstants.BLACK));
        document.add(contenidoParrafo);

        // Cerrar documento
        document.close();
    }

    public static void main(String[] args) {
        GeneradorPDF generadorPDF = new GeneradorPDF();
        try {
            generadorPDF.generarPDFConTitulo("documento.pdf", "Reporte de Ventas", "Este es un documento generado con iText.");
            System.out.println("PDF generado exitosamente.");
        } catch (IOException e) {
            System.err.println("Error al generar el PDF: " + e.getMessage());
        }
    }
}
