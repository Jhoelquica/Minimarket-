package excepcion;

public class SolicitudIncorrectaException extends RuntimeException {
    public SolicitudIncorrectaException() {
        super();
    }

    public SolicitudIncorrectaException(String mensaje) {
        super(mensaje);
    }
}
