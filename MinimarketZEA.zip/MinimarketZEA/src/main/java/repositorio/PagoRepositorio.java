package repositorio;

import modelo.Pago;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PagoRepositorio extends JpaRepository<Pago, Long> {
    // Obtener pagos por compra
    List<Pago> findByCompraId(Long compraId);

    // Obtener pagos por estado
    List<Pago> findByEstadoPago(String estadoPago);

    // Verificar si el pago existe por número de operación
    boolean existsByNroOperacion(String nroOperacion);
}
