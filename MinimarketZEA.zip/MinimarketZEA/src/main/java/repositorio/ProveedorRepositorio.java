package repositorio;

import modelo.Proveedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProveedorRepositorio extends JpaRepository<Proveedor, Long> {
    // Buscar proveedor por nombre
    Optional<Proveedor> findByNombre(String nombre);

    // Verificar si existe un proveedor con ese nombre
    boolean existsByNombre(String nombre);
}
