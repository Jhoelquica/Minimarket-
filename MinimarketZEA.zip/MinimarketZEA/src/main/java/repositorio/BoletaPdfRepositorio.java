package repositorio;

import modelo.BoletaPdf;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BoletaPdfRepositorio extends JpaRepository<BoletaPdf, Long> {
    // Obtener boleta PDF por venta
    BoletaPdf findByVentaId(Long ventaId);
}
