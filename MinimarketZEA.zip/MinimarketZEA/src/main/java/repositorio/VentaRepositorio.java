package repositorio;

import modelo.Venta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VentaRepositorio extends JpaRepository<Venta, Long> {
    // Obtener ventas por cliente
    List<Venta> findByCompraClienteId(Long clienteId);

    // Obtener ventas por estado
    List<Venta> findByCompraEstado(String estado);

    // Obtener ventas dentro de un rango de fechas
    List<Venta> findByFechaVentaBetween(String fechaInicio, String fechaFin);
}
