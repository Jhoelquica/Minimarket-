package repositorio;

import modelo.Compra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CompraRepositorio extends JpaRepository<Compra, Long> {
    // Obtener todas las compras de un cliente
    List<Compra> findByClienteId(Long clienteId);

    // Obtener compras por estado
    List<Compra> findByEstado(String estado);

    // Obtener compras por método de pago
    List<Compra> findByMetodoPago(String metodoPago);

    List<Compra> findByFechaBetween(String fechaInicio, String fechaFin);
}
