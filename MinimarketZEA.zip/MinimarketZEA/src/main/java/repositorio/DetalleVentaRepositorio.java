package repositorio;

import modelo.DetalleVenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DetalleVentaRepositorio extends JpaRepository<DetalleVenta, Long> {
    // Obtener detalles de una venta
    List<DetalleVenta> findByVentaId(Long ventaId);

    // Obtener detalles por producto
    List<DetalleVenta> findByProductoId(Long productoId);
}
