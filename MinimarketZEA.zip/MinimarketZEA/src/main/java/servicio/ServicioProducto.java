package servicio;

import modelo.Producto;
import repositorio.ProductoRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioProducto {

    private final ProductoRepositorio productoRepositorio;

    public ServicioProducto(ProductoRepositorio productoRepositorio) {
        this.productoRepositorio = productoRepositorio;
    }

    public Producto crearProducto(Producto producto) {
        return productoRepositorio.save(producto);
    }

    public Producto obtenerPorId(Long id) {
        return productoRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Producto no encontrado con id " + id));
    }

    public List<Producto> listarTodos() {
        return productoRepositorio.findAll();
    }

    public Producto actualizarProducto(Long id, Producto datosProducto) {
        Producto producto = obtenerPorId(id);
        producto.setNombre(datosProducto.getNombre());
        producto.setDescripcion(datosProducto.getDescripcion());
        producto.setPrecio(datosProducto.getPrecio());
        producto.setStock(datosProducto.getStock());
        return productoRepositorio.save(producto);
    }

    public void eliminarProducto(Long id) {
        Producto producto = obtenerPorId(id);
        productoRepositorio.delete(producto);
    }
}

