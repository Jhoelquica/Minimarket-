package servicio;

import modelo.Compra;
import repositorio.CompraRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioReporte {

    private final CompraRepositorio compraRepositorio;

    public ServicioReporte(CompraRepositorio compraRepositorio) {
        this.compraRepositorio = compraRepositorio;
    }

    // Generar reporte de compras por cliente
    public List<Compra> generarReporteComprasPorCliente(Long clienteId) {
        return compraRepositorio.findByClienteId(clienteId);
    }

    // Generar reporte de compras por estado
    public List<Compra> generarReporteComprasPorEstado(String estado) {
        return compraRepositorio.findByEstado(estado);
    }

    // Generar reporte de compras por método de pago
    public List<Compra> generarReporteComprasPorMetodoPago(String metodoPago) {
        return compraRepositorio.findByMetodoPago(metodoPago);
    }

    // Reporte de compras entre fechas
    public List<Compra> generarReportePorFecha(String fechaInicio, String fechaFin) {
        return compraRepositorio.findByFechaBetween(fechaInicio, fechaFin);
    }
}

