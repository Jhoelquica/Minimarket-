package servicio;

import modelo.Compra;
import modelo.Pago;
import repositorio.PagoRepositorio;
import repositorio.CompraRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioPago {

    private final PagoRepositorio pagoRepositorio;
    private final CompraRepositorio compraRepositorio;

    public ServicioPago(PagoRepositorio pagoRepositorio, CompraRepositorio compraRepositorio) {
        this.pagoRepositorio = pagoRepositorio;
        this.compraRepositorio = compraRepositorio;
    }

    public Pago crearPago(Pago pago, Long compraId) {
        Compra compra = compraRepositorio.findById(compraId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Compra no encontrada con id " + compraId));
        pago.setCompra(compra);
        return pagoRepositorio.save(pago);
    }

    public Pago obtenerPorId(Long id) {
        return pagoRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pago no encontrado con id " + id));
    }

    public List<Pago> listarTodos() {
        return pagoRepositorio.findAll();
    }

    public Pago actualizarPago(Long id, Pago datosPago) {
        Pago pago = obtenerPorId(id);
        pago.setTipoPago(datosPago.getTipoPago());
        pago.setNroOperacion(datosPago.getNroOperacion());
        pago.setDatosCliente(datosPago.getDatosCliente());
        pago.setEstadoPago(datosPago.getEstadoPago());
        return pagoRepositorio.save(pago);
    }

    public void eliminarPago(Long id) {
        Pago pago = obtenerPorId(id);
        pagoRepositorio.delete(pago);
    }
}
