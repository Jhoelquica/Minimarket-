package servicio;

import modelo.Cliente;
import repositorio.ClienteRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioCliente {

    private final ClienteRepositorio clienteRepositorio;

    public ServicioCliente(ClienteRepositorio clienteRepositorio) {
        this.clienteRepositorio = clienteRepositorio;
    }

    public Cliente crearCliente(Cliente cliente) {
        return clienteRepositorio.save(cliente);
    }

    public Cliente obtenerPorId(Long id) {
        return clienteRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado con id " + id));
    }

    public List<Cliente> listarTodos() {
        return clienteRepositorio.findAll();
    }

    public Cliente actualizarCliente(Long id, Cliente datosCliente) {
        Cliente cliente = obtenerPorId(id);
        cliente.setNombre(datosCliente.getNombre());
        cliente.setEmail(datosCliente.getEmail());
        cliente.setTelefono(datosCliente.getTelefono());
        cliente.setDireccion(datosCliente.getDireccion());
        return clienteRepositorio.save(cliente);
    }

    public void eliminarCliente(Long id) {
        Cliente cliente = obtenerPorId(id);
        clienteRepositorio.delete(cliente);
    }
}

