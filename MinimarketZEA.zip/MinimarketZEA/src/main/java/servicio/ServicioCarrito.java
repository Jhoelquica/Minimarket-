package servicio;

import modelo.ItemCarrito;
import modelo.Cliente;
import modelo.Producto;
import repositorio.ItemCarritoRepositorio;
import repositorio.ClienteRepositorio;
import repositorio.ProductoRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioCarrito {

    private final ItemCarritoRepositorio itemCarritoRepositorio;
    private final ClienteRepositorio clienteRepositorio;
    private final ProductoRepositorio productoRepositorio;

    public ServicioCarrito(ItemCarritoRepositorio itemCarritoRepositorio,
                           ClienteRepositorio clienteRepositorio,
                           ProductoRepositorio productoRepositorio) {
        this.itemCarritoRepositorio = itemCarritoRepositorio;
        this.clienteRepositorio = clienteRepositorio;
        this.productoRepositorio = productoRepositorio;
    }

    public ItemCarrito agregarProductoAlCarrito(Long clienteId, Long productoId, Integer cantidad) {
        Cliente cliente = clienteRepositorio.findById(clienteId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado con id " + clienteId));

        Producto producto = productoRepositorio.findById(productoId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Producto no encontrado con id " + productoId));

        ItemCarrito item = new ItemCarrito();
        item.setCliente(cliente);
        item.setProducto(producto);
        item.setCantidad(cantidad);
        return itemCarritoRepositorio.save(item);
    }

    public List<ItemCarrito> obtenerCarritoPorCliente(Long clienteId) {
        return itemCarritoRepositorio.findByClienteId(clienteId);
    }

    public void eliminarProductoDelCarrito(Long clienteId, Long productoId) {
        ItemCarrito item = itemCarritoRepositorio.findByClienteIdAndProductoId(clienteId, productoId);
        if (item != null) {
            itemCarritoRepositorio.delete(item);
        }
    }
}
