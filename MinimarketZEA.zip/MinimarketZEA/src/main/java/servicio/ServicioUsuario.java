package servicio;

import modelo.Usuario;
import repositorio.UsuarioRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioUsuario {

    private final UsuarioRepositorio usuarioRepositorio;

    public ServicioUsuario(UsuarioRepositorio usuarioRepositorio) {
        this.usuarioRepositorio = usuarioRepositorio;
    }

    public Usuario crearUsuario(Usuario usuario) {
        return usuarioRepositorio.save(usuario);
    }

    public Usuario obtenerPorId(Long id) {
        return usuarioRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con id " + id));
    }

    public List<Usuario> listarTodos() {
        return usuarioRepositorio.findAll();
    }

    public Usuario actualizarUsuario(Long id, Usuario datosUsuario) {
        Usuario usuario = obtenerPorId(id);
        usuario.setNombreUsuario(datosUsuario.getNombreUsuario());
        usuario.setEmail(datosUsuario.getEmail());
        usuario.setContraseña(datosUsuario.getContraseña());
        usuario.setRol(datosUsuario.getRol());
        return usuarioRepositorio.save(usuario);
    }

    public void eliminarUsuario(Long id) {
        Usuario usuario = obtenerPorId(id);
        usuarioRepositorio.delete(usuario);
    }
}

