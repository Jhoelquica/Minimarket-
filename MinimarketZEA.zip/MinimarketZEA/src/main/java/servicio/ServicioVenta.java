package servicio;

import modelo.Compra;
import modelo.Venta;
import repositorio.VentaRepositorio;
import repositorio.CompraRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioVenta {

    private final VentaRepositorio ventaRepositorio;
    private final CompraRepositorio compraRepositorio;

    public ServicioVenta(VentaRepositorio ventaRepositorio, CompraRepositorio compraRepositorio) {
        this.ventaRepositorio = ventaRepositorio;
        this.compraRepositorio = compraRepositorio;
    }

    public Venta crearVenta(Venta venta, Long compraId) {
        Compra compra = compraRepositorio.findById(compraId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Compra no encontrada con id " + compraId));
        venta.setCompra(compra);
        return ventaRepositorio.save(venta);
    }

    public Venta obtenerPorId(Long id) {
        return ventaRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Venta no encontrada con id " + id));
    }

    public List<Venta> listarTodas() {
        return ventaRepositorio.findAll();
    }

    public Venta actualizarVenta(Long id, Venta datosVenta) {
        Venta venta = obtenerPorId(id);
        venta.setFechaVenta(datosVenta.getFechaVenta());
        venta.setTotal(datosVenta.getTotal());
        return ventaRepositorio.save(venta);
    }

    public void eliminarVenta(Long id) {
        Venta venta = obtenerPorId(id);
        ventaRepositorio.delete(venta);
    }
}

