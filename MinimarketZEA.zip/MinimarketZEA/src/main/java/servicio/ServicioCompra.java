package servicio;

import modelo.Cliente;
import modelo.Compra;
import repositorio.CompraRepositorio;
import repositorio.ClienteRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioCompra {

    private final CompraRepositorio compraRepositorio;
    private final ClienteRepositorio clienteRepositorio;

    public ServicioCompra(CompraRepositorio compraRepositorio, ClienteRepositorio clienteRepositorio) {
        this.compraRepositorio = compraRepositorio;
        this.clienteRepositorio = clienteRepositorio;
    }

    public Compra crearCompra(Compra compra, Long clienteId) {
        Cliente cliente = clienteRepositorio.findById(clienteId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado con id " + clienteId));
        compra.setCliente(cliente);
        return compraRepositorio.save(compra);
    }

    public Compra obtenerPorId(Long id) {
        return compraRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Compra no encontrada con id " + id));
    }

    public List<Compra> listarTodas() {
        return compraRepositorio.findAll();
    }

    public Compra actualizarCompra(Long id, Compra datosCompra) {
        Compra compra = obtenerPorId(id);
        compra.setTotal(datosCompra.getTotal());
        compra.setEstado(datosCompra.getEstado());
        compra.setMetodoPago(datosCompra.getMetodoPago());
        return compraRepositorio.save(compra);
    }

    public void eliminarCompra(Long id) {
        Compra compra = obtenerPorId(id);
        compraRepositorio.delete(compra);
    }
}
