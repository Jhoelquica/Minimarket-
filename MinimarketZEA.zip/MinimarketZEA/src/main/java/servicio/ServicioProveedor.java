package servicio;

import modelo.Proveedor;
import repositorio.ProveedorRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioProveedor {

    private final ProveedorRepositorio proveedorRepositorio;

    public ServicioProveedor(ProveedorRepositorio proveedorRepositorio) {
        this.proveedorRepositorio = proveedorRepositorio;
    }

    public Proveedor crearProveedor(Proveedor proveedor) {
        return proveedorRepositorio.save(proveedor);
    }

    public Proveedor obtenerPorId(Long id) {
        return proveedorRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Proveedor no encontrado con id " + id));
    }

    public List<Proveedor> listarTodos() {
        return proveedorRepositorio.findAll();
    }

    public Proveedor actualizarProveedor(Long id, Proveedor datosProveedor) {
        Proveedor proveedor = obtenerPorId(id);
        proveedor.setNombre(datosProveedor.getNombre());
        proveedor.setContacto(datosProveedor.getContacto());
        return proveedorRepositorio.save(proveedor);
    }

    public void eliminarProveedor(Long id) {
        Proveedor proveedor = obtenerPorId(id);
        proveedorRepositorio.delete(proveedor);
    }
}
